import { lazy, Suspense, useCallback, useEffect, useRef, useState } from 'react';
import { Headphones } from 'lucide-react';
import { MothMark, PixelLogo } from './components/Brand';

const Game = lazy(() => import('./game/Game'));

function WorldBackdrop() {
  return (
    <div className="world-backdrop" aria-hidden="true">
      <div className="world-image" />
      <div className="world-shade" />
      <div className="world-grain" />
      <div className="world-motes">
        {Array.from({ length: 17 }, (_, i) => (
          <i key={i} style={{
            left: `${(i * 37 + 11) % 100}%`,
            top: `${(i * 23 + 39) % 100}%`,
            animationDelay: `${-i * 2.3}s`,
            animationDuration: `${13 + i % 7 * 3}s`,
          }} />
        ))}
      </div>
    </div>
  );
}

function LoadingWorld() {
  return (
    <div className="loading-world" role="status">
      <MothMark />
      <span>THE WORLD IS WAKING</span>
      <div className="loading-line"><i /></div>
    </div>
  );
}

export default function App() {
  const [started, setStarted] = useState(false);
  const [leaving, setLeaving] = useState(false);
  const startTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const start = useCallback(() => {
    if (leaving || started) return;
    setLeaving(true);
    startTimer.current = setTimeout(() => setStarted(true), 650);
  }, [leaving, started]);

  useEffect(() => {
    if (started) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.code === 'Enter' && !event.repeat) start();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [start, started]);

  useEffect(() => () => {
    if (startTimer.current) clearTimeout(startTimer.current);
  }, []);

  return (
    <main className={`ernas-app ${leaving ? 'is-entering' : ''} ${started ? 'is-playing' : ''}`}>
      <WorldBackdrop />
      {!started ? (
        <section className="title-screen" aria-label="ERNAS main menu">
          <header className="title-header">
            <div className="studio-mark"><MothMark /><span>AN UNFAMILIAR WORLD</span></div>
            <span className="build-label"><i />PRE-ALPHA 0.2.0</span>
          </header>
          <div className="title-composition">
            <p className="title-eyebrow">THERE IS NO OUTSIDE.</p>
            <h1 className="game-title"><span className="sr-only">ERNAS</span><PixelLogo /></h1>
            <p className="title-description">A world to shape. A world to survive.</p>
            <div className="start-group">
              <button className="start-button" onClick={start} disabled={leaving}>
                <span className="start-arrow" aria-hidden="true" />
                <span>START</span>
                <span className="start-arrow right" aria-hidden="true" />
              </button>
              <span className="start-hint">PRESS ENTER TO BEGIN</span>
            </div>
          </div>
          <footer className="title-footer">
            <span>VOXEL SANDBOX / SURVIVAL HORROR</span>
            <span className="headphone-note"><Headphones size={13} strokeWidth={1.5} />HEADPHONES RECOMMENDED</span>
            <span className="footer-copyright">SOMETHING IS WAITING.</span>
          </footer>
        </section>
      ) : (
        <Suspense fallback={<LoadingWorld />}>
          <Game onExit={() => { setStarted(false); setLeaving(false); }} />
        </Suspense>
      )}
    </main>
  );
}
