import * as THREE from 'three';
import { CIRCUMFERENCE, HALF_LENGTH, RADIUS } from './biomes';

export const FACES = [
  { direction: [1, 0, 0], shade: .84, corners: [[.5, -.5, -.5], [.5, .5, -.5], [.5, .5, .5], [.5, -.5, .5]] },
  { direction: [-1, 0, 0], shade: .76, corners: [[-.5, -.5, .5], [-.5, .5, .5], [-.5, .5, -.5], [-.5, -.5, -.5]] },
  { direction: [0, 1, 0], shade: 1, corners: [[-.5, .5, -.5], [-.5, .5, .5], [.5, .5, .5], [.5, .5, -.5]] },
  { direction: [0, -1, 0], shade: .49, corners: [[-.5, -.5, .5], [-.5, -.5, -.5], [.5, -.5, -.5], [.5, -.5, .5]] },
  { direction: [0, 0, 1], shade: .87, corners: [[.5, -.5, .5], [.5, .5, .5], [-.5, .5, .5], [-.5, -.5, .5]] },
  { direction: [0, 0, -1], shade: .8, corners: [[-.5, -.5, -.5], [-.5, .5, -.5], [.5, .5, -.5], [.5, -.5, -.5]] },
];

export class FaceBuilder {
  positions: number[] = [];
  normals: number[] = [];
  colors: number[] = [];
  uvs: number[] = [];
  indices: number[] = [];
  cells: number[] = [];

  face(x: number, y: number, z: number, faceIndex: number, color: THREE.Color, width = 1, height = 1, depth = 1, cell?: [number, number]) {
    const face = FACES[faceIndex], index = this.positions.length / 3;
    const angle = x / RADIUS, sin = Math.sin(angle), cos = Math.cos(angle);
    const [nx, ny, nz] = face.direction;
    const shade = face.shade;
    for (let i = 0; i < 4; i++) {
      const [dx, dy, dz] = face.corners[i];
      const u = (x + dx * width) / RADIUS, r = RADIUS - y - dy * height;
      this.positions.push(Math.sin(u) * r, -Math.cos(u) * r, z + dz * depth);
      this.normals.push(nx * cos - ny * sin, nx * sin + ny * cos, nz);
      this.colors.push(color.r * shade, color.g * shade, color.b * shade);
      this.uvs.push(i === 1 || i === 2 ? 1 : 0, i >= 2 ? 1 : 0);
      if (cell) this.cells.push(cell[0] < 0 ? (x + dx * width + CIRCUMFERENCE / 2) / CIRCUMFERENCE : cell[0], cell[1] < 0 ? (z + dz * depth + HALF_LENGTH) / (HALF_LENGTH * 2) : cell[1]);
    }
    this.indices.push(index, index + 1, index + 2, index, index + 2, index + 3);
  }

  box(x: number, y: number, z: number, width: number, height: number, depth: number, color: THREE.Color, cell?: [number, number]) {
    for (let i = 0; i < 6; i++) this.face(x, y, z, i, color, width, height, depth, cell);
  }

  geometry() {
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(this.positions, 3));
    geometry.setAttribute('normal', new THREE.Float32BufferAttribute(this.normals, 3));
    geometry.setAttribute('color', new THREE.Float32BufferAttribute(this.colors, 3));
    geometry.setAttribute('uv', new THREE.Float32BufferAttribute(this.uvs, 2));
    if (this.cells.length) geometry.setAttribute('cellUv', new THREE.Float32BufferAttribute(this.cells, 2));
    geometry.setIndex(this.indices);
    geometry.computeBoundingSphere();
    return geometry;
  }
}